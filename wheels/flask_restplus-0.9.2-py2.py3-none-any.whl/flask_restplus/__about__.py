# -*- coding: utf-8 -*-
__version__ = '0.9.2'
__description__ = 'Fully featured framework for fast, easy and documented API development with Flask'
